import pygame
import random
from misc import SCREEN_WIDTH as WIDTH, SCREEN_HEIGHT as HEIGHT, TILE_SIZE
import sys
from collections import deque
from tilemap import TileMap
from spritesheet_loader import SpriteSheet
from colours import *
from spritesheet_loader import *
from player import PlayerMovement
from dialogueview import DialogueView
import pytmx

def play_first_quest():
    pygame.init()
    win = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Rabbit-hole!")
    FPS = 60
    clock = pygame.time.Clock()

    # Load TMX map
    tmx = TileMap("resources/quest1map.tmx")

    # Prepare tiles, obstacles, and special objects
    floor_tiles = []
    obstacles = []
    player_spawn = None
    bottom_rect = None

    for obj in tmx.interactables:
        obj_type = obj["type"].lower()
        rect = obj["rect"]
        if obj_type == "spawn":
            PLAYER_SIZE = 32
            player_spawn = pygame.Rect(rect.x, rect.y, PLAYER_SIZE, PLAYER_SIZE)
        elif obj_type == "bottom":
            bottom_rect = rect

    if not player_spawn or not bottom_rect:
        raise ValueError("TMX map missing 'spawn' or 'bottom' object.")

    # Initialize player sprite
    player_sprite = PlayerMovement(WIDTH, HEIGHT, WIDTH)
    player_sprite.player_x = player_spawn.x
    player_sprite.player_y = player_spawn.y
    player_sprite.rect.topleft = (player_spawn.x, player_spawn.y)

    # Load floor tiles
    tilewidth = tmx.tmx_data.tilewidth
    tileheight = tmx.tmx_data.tileheight
    floor_layer = tmx.tmx_data.get_layer_by_name("floor")
    for x, y, gid in floor_layer:
        if gid:
            floor_tiles.append(pygame.Rect(x*tilewidth, y*tileheight, tilewidth, tileheight))

    # Load obstacles if layer exists
    try:
        obs_layer = tmx.tmx_data.get_layer_by_name("obs")
        for x, y, gid in obs_layer:
            if gid:
                obstacles.append(pygame.Rect(x*tilewidth, y*tileheight, tilewidth, tileheight))
    except ValueError:
        pass

    # Game loop variables
    camera_offset_y = 0
    run = True
    falling = False
    on_floor = False
    quest_result = None
    showing_dialogue = False
    dialogue_box = None
    map_height_px = tmx.tmx_data.height * tileheight
    BUFFER = 5  # leniency for obstacle collision

    while run:
        clock.tick(FPS)
        win.fill(WHITE)
        keys = pygame.key.get_pressed()

        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                quest_result = "quit"
            elif event.type == pygame.KEYDOWN and showing_dialogue:
                if dialogue_box.handle_input(event.key) == "CLOSE":
                    showing_dialogue = False
                    run = False  # end loop after dialogue

        # Player movement only if not showing dialogue
        if not showing_dialogue:
            player_sprite.handle_input(keys)
            player_sprite.apply_gravity()
            player_sprite.update_position(floor_tiles, [])
            player_sprite.update_animation(keys)

        # Falling check
        if not falling and not on_floor:
            feet_rect = player_sprite.rect.copy()
            feet_rect.y += 1
            if not any(feet_rect.colliderect(tile) for tile in floor_tiles):
                falling = True

        # Landing check
        if falling and not on_floor:
            if player_sprite.rect.bottom >= bottom_rect.top:
                on_floor = True
                player_sprite.rect.bottom = bottom_rect.top
                quest_result = "win"  # player successfully landed
                font_path = "resources/Minecraft.ttf"
                dialogue_text = "Congrats! You landed safely. Press E to exit."
                dialogue_box = DialogueView(font_path, dialogue_text, mode="quest_win")
                showing_dialogue = True

        # Camera follow
        target_offset = player_sprite.rect.centery - HEIGHT // 2
        camera_offset_y = max(0, min(target_offset, map_height_px - HEIGHT))

        # Draw everything
        tmx.draw(win, pygame.Vector2(0, camera_offset_y))
        tmx.draw_texts(win, pygame.Vector2(0, camera_offset_y))
        player_sprite.draw(win, keys, pygame.Vector2(0, camera_offset_y))
        if showing_dialogue:
            dialogue_box.update()
            dialogue_box.draw(win)

        # Obstacle collisions with buffer
        player_collision_rect = pygame.Rect(
            player_sprite.rect.x + (player_sprite.PLAYER_WIDTH - player_sprite.COLLISION_WIDTH) // 2 + BUFFER//2,
            player_sprite.rect.y + (player_sprite.PLAYER_HEIGHT - player_sprite.COLLISION_HEIGHT) // 2 + BUFFER//2,
            player_sprite.COLLISION_WIDTH - BUFFER,
            player_sprite.COLLISION_HEIGHT - BUFFER
        )

        for obs in obstacles:
            obs_buf = obs.inflate(-BUFFER, -BUFFER)
            if player_collision_rect.colliderect(obs_buf):
                quest_result = "lose"
                font_path = "resources/Minecraft.ttf"
                dialogue_text = "Oops! You hit an obstacle. Press E to exit."
                dialogue_box = DialogueView(font_path, dialogue_text, mode="quest_fail")
                showing_dialogue = True
                falling = False  # stop gravity/movement
                break

        pygame.display.update()

    return quest_result

def play_second_quest():
    pygame.init()
    win = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Pac-Mouse!")

    WALL_COLOR = (0, 0, 255)
    DOT_COLOR = (255, 255, 255)
    PLAYER_COLOR = (255, 255, 0)
    GHOST1_COLOR = (255, 0, 0)
    GHOST2_COLOR = (255, 105, 180)

    maze = [
        "WWWWWWWWWWWWWWWWWWW",
        "W....            .W",
        "W.W     W   W     W",
        "W.WW W   WW WW    W",
        "W....     ....    W",
        "W.WW WW       W  WW",
        "W.       W        W",
        "W.WW      W       W",
        "W     ..     .    W",
        "W   W   WW WW .   W",
        "WWWWWWWWWWWWWWWWWWW"
    ]


    ROWS = len(maze)
    COLS = len(maze[0])
    maze_width = COLS * TILE_SIZE
    maze_height = ROWS * TILE_SIZE

    draw_offset_x = 97 # higher = more right
    draw_offset_y = 225 # higher = more down

    background = pygame.image.load("resources/quest2/quest2screen.png").convert()
    background = pygame.transform.scale(background, (WIDTH, HEIGHT))

    walls = []
    points = []
    ghosts = []

    for y, row in enumerate(maze):
        for x, char in enumerate(row):
            px = draw_offset_x + x * TILE_SIZE
            py = draw_offset_y + y * TILE_SIZE

            if char == 'W':
                walls.append(pygame.Rect(px, py, TILE_SIZE, TILE_SIZE))
            elif char == '.':
                points.append(pygame.Rect(px + TILE_SIZE // 4, py + TILE_SIZE // 4, TILE_SIZE // 2, TILE_SIZE // 2))
            elif char == 'G':
                ghosts.append(pygame.Rect(px, py, TILE_SIZE, TILE_SIZE))

    player = pygame.Rect(draw_offset_x + TILE_SIZE, draw_offset_y + TILE_SIZE, TILE_SIZE, TILE_SIZE)

    ghost = ghosts[0] if len(ghosts) > 0 else pygame.Rect(draw_offset_x + (COLS - 2) * TILE_SIZE, draw_offset_y + (ROWS - 2) * TILE_SIZE, TILE_SIZE, TILE_SIZE)
    ghost2 = ghosts[1] if len(ghosts) > 1 else pygame.Rect(draw_offset_x + TILE_SIZE * (COLS - 3), draw_offset_y + TILE_SIZE, TILE_SIZE, TILE_SIZE)

    clock = pygame.time.Clock()
    run = True
    quest_result = None
    game_started = False
    ghost_move_timer = 0
    ghost_move_interval = 2
    showing_dialogue = False
    dialogue_box = None

    def can_move(rect, ignore_ghost=None):
        # Check walls and screen bounds as before
        if rect.left < draw_offset_x or rect.right > draw_offset_x + maze_width:
            return False
        if rect.top < draw_offset_y or rect.bottom > draw_offset_y + maze_height:
            return False
        if any(rect.colliderect(w) for w in walls):
            return False
        # Prevent collision with the other ghost
        if ignore_ghost != ghost and rect.colliderect(ghost):
            return False
        if ignore_ghost != ghost2 and rect.colliderect(ghost2):
            return False
        return True

    def move(rect, dx, dy, ignore_ghost=None):
        new_rect = rect.move(dx * TILE_SIZE, dy * TILE_SIZE)
        if can_move(new_rect, ignore_ghost):
            rect.x = new_rect.x
            rect.y = new_rect.y


    def ghost_chase(ghost_rect, ignore_ghost=None):
        start = ((ghost_rect.x - draw_offset_x) // TILE_SIZE, (ghost_rect.y - draw_offset_y) // TILE_SIZE)
        goal = ((player.x - draw_offset_x) // TILE_SIZE, (player.y - draw_offset_y) // TILE_SIZE)
        queue = deque([(start, [])])
        visited = set()

        while queue:
            (x, y), path = queue.popleft()
            if (x, y) == goal:
                if path:
                    dx, dy = path[0]
                    move(ghost_rect, dx, dy, ignore_ghost)
                return
            for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
                nx, ny = x+dx, y+dy
                if 0 <= nx < COLS and 0 <= ny < ROWS and maze[ny][nx] != 'W' and (nx, ny) not in visited:
                    visited.add((nx, ny))
                    queue.append(((nx, ny), path+[(dx, dy)]))


            while queue:
                (x, y), path = queue.popleft()
                if (x, y) == goal:
                    if path:
                        dx, dy = path[0]
                        move(ghost_rect, dx, dy)
                    return
                for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
                    nx, ny = x+dx, y+dy
                    if 0 <= nx < COLS and 0 <= ny < ROWS and maze[ny][nx] != 'W' and (nx, ny) not in visited:
                        visited.add((nx, ny))
                        queue.append(((nx, ny), path+[(dx, dy)]))

            # If no path found, ghost does not move this turn (safe fallback)

    while run:
        clock.tick(8)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                quest_result = "quit"
            elif event.type == pygame.KEYDOWN and showing_dialogue:
                if dialogue_box.handle_input(event.key) == "CLOSE":
                    showing_dialogue = False
                    run = False  # end loop after dialogue

        keys = pygame.key.get_pressed()
        if not game_started and keys[pygame.K_SPACE]:
            game_started = True

        if game_started:
            if keys[pygame.K_a]:
                move(player, -1, 0)
            if keys[pygame.K_d]:
                move(player, 1, 0)
            if keys[pygame.K_w]:
                move(player, 0, -1)
            if keys[pygame.K_s]:
                move(player, 0, 1)

            ghost_move_timer += 1
            if ghost_move_timer >= ghost_move_interval:
                ghost_chase(ghost, ignore_ghost=ghost)
                ghost_chase(ghost2, ignore_ghost=ghost2)

                ghost_move_timer = 0

            points = [p for p in points if not player.colliderect(p)]

            if not points:
                print("You Win!")
                quest_result = "win"
                font_path = "resources/Minecraft.ttf"
                dialogue_text = "Congrats! You landed safely. Press E to exit."
                dialogue_box = DialogueView(font_path, dialogue_text, mode="quest_win")
                showing_dialogue = True

            if player.colliderect(ghost):
                print("Caught by Ghost! You Lose.")
                quest_result = "lose"
                font_path = "resources/Minecraft.ttf"
                dialogue_text = "Oops! You got caught by the ghost. Press E to exit."
                dialogue_box = DialogueView(font_path, dialogue_text, mode="quest_fail")
                showing_dialogue = True

            if player.colliderect(ghost2):
                print("Caught by Second Ghost! You Lose.")
                quest_result = "lose"
                font_path = "resources/Minecraft.ttf"
                dialogue_text = "Oops! You got caught by the ghost. Press E to exit."
                dialogue_box = DialogueView(font_path, dialogue_text, mode="quest_fail")
                showing_dialogue = True

        win.blit(background, (0, 0))

        for wall in walls:
            pygame.draw.rect(win, WALL_COLOR, wall)
        for p in points:
            pygame.draw.rect(win, DOT_COLOR, p)

        pygame.draw.rect(win, PLAYER_COLOR, player)
        pygame.draw.rect(win, GHOST1_COLOR, ghost)
        pygame.draw.rect(win, GHOST2_COLOR, ghost2)
        if showing_dialogue:
            dialogue_box.update()
            dialogue_box.draw(win)

        pygame.display.update()

    return quest_result

def play_third_quest():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    pygame.display.set_caption("Stealth Heist")
    FPS = 60

    tmx = TileMap("resources/mazemap2.tmx")

    # === Define spritesheet loading function ===
    def load_spritesheet_local(image_path, frame_count, frame_width, frame_height):
        spritesheet = pygame.image.load(image_path)
        sprite_width, sprite_height = spritesheet.get_size()
        
        # Debug print to see actual dimensions
        print(f"Loading {image_path}: {sprite_width}x{sprite_height}, expecting {frame_count} frames of {frame_width}x{frame_height}")
        
        frames = []
        for i in range(frame_count):
            x = i * frame_width
            # Check if we're trying to go outside the image bounds
            if x + frame_width > sprite_width or frame_height > sprite_height:
                print(f"Warning: Frame {i} would be outside image bounds. Skipping.")
                break
            
            frame = spritesheet.subsurface(pygame.Rect(x, 0, frame_width, frame_height))
            frames.append(frame)
        
        if not frames:
            # Fallback: create a single frame from the whole image
            print(f"No valid frames found, using whole image as single frame")
            frames = [spritesheet]
            
        return frames

    # === Load NPC animation frames and pre-flip for left movement ===
    cat_frames_raw = load_spritesheet_local('resources/quest2npc.png', 8, 32, 32)
    print(f"Loaded {len(cat_frames_raw)} cat frames")
    cat_frames_left = [pygame.transform.scale(frame, (TILE_SIZE, TILE_SIZE)) for frame in cat_frames_raw]
    cat_frames_right = [pygame.transform.flip(frame, True, False) for frame in cat_frames_left]

    # Load player animations
    player_idle_frames = load_spritesheet_local('resources/idle.png', 4, 32, 32)
    player_movement_frames = load_spritesheet_local('resources/MOUSE.png', 8, 32, 32)
    
    # Scale player frames to match game size
    PLAYER_SPRITE_SIZE = 48  # Increased from 32 to make player bigger
    player_idle_frames = [pygame.transform.scale(frame, (PLAYER_SPRITE_SIZE, PLAYER_SPRITE_SIZE)) for frame in player_idle_frames]
    player_movement_frames = [pygame.transform.scale(frame, (PLAYER_SPRITE_SIZE, PLAYER_SPRITE_SIZE)) for frame in player_movement_frames]
    
    player = None
    exit_rects = []
    cats = []
    walls = tmx.floor_rects

    # Player animation variables
    player_animation = {
        "current_frame": 0,
        "frame_timer": 0,
        "frame_delay": 8,  # Adjust speed of animation
        "last_direction_left": False,
        "velocity_x": 0,
        "velocity_y": 0
    }

    for obj in tmx.interactables:
        if obj["type"].lower() == "spawn":
            PLAYER_SIZE = 32
            player = pygame.Rect(obj["rect"].x, obj["rect"].y, PLAYER_SIZE, PLAYER_SIZE)
        elif obj["type"].lower() == "exit":
            exit_rects.append(obj["rect"])
        elif obj["type"].lower() == "cat":
            props = obj.get("properties", {})
            patrol_tiles = int(props.get("patrol_length", props.get("patrol length", 1)))
            direction = props.get("direction", "horizontal").lower()
            start_dir = props.get("start_direction", "right").lower()

            cat = {
                "name": obj.get("name", f"npc{len(cats)+1}"),
                "rect": pygame.Rect(obj["rect"].x, obj["rect"].y, TILE_SIZE, TILE_SIZE),
                "origin": (obj["rect"].x, obj["rect"].y),
                "axis": direction,
                "direction": 1 if start_dir in ("right", "down") else -1,
                "patrol_range": patrol_tiles * TILE_SIZE,
                "speed": 1,
                "frame_index": 0,
                "frame_timer": 0,
                "facing_right": True
            }
            cats.append(cat)

    def move_player(rect, dx, dy):
        next_rect = rect.move(dx, dy)
        if not any(next_rect.colliderect(w) for w in walls):
            rect.x += dx
            rect.y += dy
            return True
        return False

    def update_player():
        keys = pygame.key.get_pressed()
        dx = dy = 0
        player_animation["velocity_x"] = 0
        player_animation["velocity_y"] = 0
        
        if keys[pygame.K_a]: 
            dx = -TILE_SIZE // 6
            player_animation["velocity_x"] = dx
            player_animation["last_direction_left"] = True
        if keys[pygame.K_d]: 
            dx = TILE_SIZE // 6
            player_animation["velocity_x"] = dx
            player_animation["last_direction_left"] = False
        if keys[pygame.K_w]: 
            dy = -TILE_SIZE // 6
            player_animation["velocity_y"] = dy
        if keys[pygame.K_s]: 
            dy = TILE_SIZE // 6
            player_animation["velocity_y"] = dy
            
        if dx or dy:
            move_player(player, dx, dy)

    def update_player_animation():
        # Check if player is moving
        is_moving = player_animation["velocity_x"] != 0 or player_animation["velocity_y"] != 0
        
        player_animation["frame_timer"] += 1
        if player_animation["frame_timer"] >= player_animation["frame_delay"]:
            player_animation["frame_timer"] = 0
            
            if is_moving:
                # Use movement animation
                player_animation["current_frame"] = (player_animation["current_frame"] + 1) % len(player_movement_frames)
            else:
                # Use idle animation
                player_animation["current_frame"] = (player_animation["current_frame"] + 1) % len(player_idle_frames)

    def draw_player(screen):
        # Determine which animation to use
        is_moving = player_animation["velocity_x"] != 0 or player_animation["velocity_y"] != 0
        
        if is_moving:
            frame = player_movement_frames[player_animation["current_frame"] % len(player_movement_frames)]
        else:
            frame = player_idle_frames[player_animation["current_frame"] % len(player_idle_frames)]
        
        # Flip sprite if moving left or last moved left
        if player_animation["velocity_x"] < 0 or (player_animation["velocity_x"] == 0 and player_animation["last_direction_left"]):
            frame = pygame.transform.flip(frame, True, False)
        
        # Center the sprite on the collision rectangle
        sprite_x = player.x - (PLAYER_SPRITE_SIZE - PLAYER_SIZE) // 2
        sprite_y = player.y - (PLAYER_SPRITE_SIZE - PLAYER_SIZE) // 2
        screen.blit(frame, (sprite_x, sprite_y))

    def is_wall_blocking(cat_rect, player_rect, axis):
        start = cat_rect.center
        end = player_rect.center
        steps = int(max(abs(end[0] - start[0]), abs(end[1] - start[1])) // 4)
        if steps == 0:
            return False
        for i in range(steps + 1):
            t = i / steps
            x = int(start[0] + (end[0] - start[0]) * t)
            y = int(start[1] + (end[1] - start[1]) * t)
            point_rect = pygame.Rect(x, y, 4, 4)
            if any(point_rect.colliderect(w) for w in walls):
                return True
        return False

    def npc_vision_rect(cat):
        rect = cat["rect"]
        direction = cat["direction"]
        length = TILE_SIZE * 5
        width = TILE_SIZE
        if cat["axis"] == "horizontal":
            x = rect.right if direction > 0 else rect.left - length
            return pygame.Rect(x, rect.centery - width // 2, length, width)
        else:
            y = rect.bottom if direction > 0 else rect.top - length
            return pygame.Rect(rect.centerx - width // 2, y, width, length)

    def update_npcs():
        for cat in cats:
            rect = cat["rect"]
            axis = cat["axis"]
            speed = cat["speed"]
            dir = cat["direction"]
            ox, oy = cat["origin"]

            if axis == "horizontal":
                rect.x += dir * speed
                if abs(rect.x - ox) >= cat["patrol_range"]:
                    cat["direction"] *= -1
            else:
                rect.y += dir * speed
                if abs(rect.y - oy) >= cat["patrol_range"]:
                    cat["direction"] *= -1

            # Update facing direction
            if axis == "horizontal":
                cat["facing_right"] = cat["direction"] > 0

            # Animation timing
            cat["frame_timer"] += 1
            if cat["frame_timer"] >= 15:  # Slower animation (was 10)
                cat["frame_timer"] = 0
                cat["frame_index"] = (cat["frame_index"] + 1) % len(cat_frames_right)

            vis = npc_vision_rect(cat)
            if vis.colliderect(player) and not is_wall_blocking(rect, player, "x" if axis == "horizontal" else "y"):
                return "lose"
        return None

    def draw():
        screen.fill(BLACK)
        tmx.draw(screen, pygame.Vector2(0, 0))
        
        # Draw animated player instead of white rectangle
        draw_player(screen)

        for cat in cats:
            frames = cat_frames_right if cat["facing_right"] else cat_frames_left
            screen.blit(frames[cat["frame_index"]], cat["rect"].topleft)
            pygame.draw.rect(screen, MAGENTA, npc_vision_rect(cat), 2)

        tmx.draw_texts(screen, pygame.Vector2(0, 0))

        # Draw dialogue box if showing
        if showing_dialogue:
            dialogue_box.update()
            dialogue_box.draw(screen)

        pygame.display.flip()

    showing_dialogue = False
    dialogue_box = None
    quest_result = None
    running = True
    while running:
        dt = clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and showing_dialogue:
                if dialogue_box.handle_input(event.key) == "CLOSE":
                    showing_dialogue = False
                    running = False

        update_player()
        update_player_animation()  # Update player animation
        npc_result = update_npcs()
        if npc_result == "lose":
            quest_result = "lose"
            font_path = "resources/Minecraft.ttf"
            dialogue_text = "Oops! You got caught. Press E to exit."
            dialogue_box = DialogueView(font_path, dialogue_text, mode="quest_fail")
            showing_dialogue = True
        if any(player.colliderect(exit_rect) for exit_rect in exit_rects):
            quest_result = "win"
            font_path = "resources/Minecraft.ttf"
            dialogue_text = "Congrats! You made it! Press E to exit."
            dialogue_box = DialogueView(font_path, dialogue_text, mode="quest_win")
            showing_dialogue = True
        draw()

    return quest_result

import pygame
from misc import *
from pygame import mixer
from pygame import font
import math


def play_fourth_quest():
    pygame.font.init()
    pygame.init()

    clock = pygame.time.Clock()
    win = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT)) 
    pygame.display.set_caption("RAT AND ROLL!") 
    print("RAT AND ROLL!") 

    # Game constants
    HIT_ZONE_Y = SCREEN_HEIGHT - 100
    HIT_ZONE_WIDTH = 25
    FPS = 60
    PROGRESS_BAR_WIDTH = SCREEN_WIDTH 
    PROGRESS_BAR_Y = SCREEN_HEIGHT - 50
    BACKGROUND = (0, 20, 50)

    # Game state variables
    run = True
    quest_result = None
    combo_count = 0
    max_combo = 0
    health = 100
    max_health = 100
    score = 0
    missed_notes = 0
    quest_failed = False
    music_started = True

    # Fonts
    font_path = "resources/Minecraft.ttf"
    font_large = pygame.font.Font(font_path, 42)
    font_medium = pygame.font.Font(font_path, 36)
    font_small = pygame.font.Font(font_path, 24)


    # Visual effects
    particles = []
    combo_display_timer = 0
    hit_effects = []

    class Particle:
        def __init__(self, x, y, color, velocity):
            self.x = x
            self.y = y
            self.color = color
            self.velocity = velocity
            self.life = 30
            self.max_life = 30
            
        def update(self):
            self.x += self.velocity[0]
            self.y += self.velocity[1]
            self.life -= 1
            
        def draw(self, surface):
            if self.life > 0:
                alpha = int(255 * (self.life / self.max_life))
                color_with_alpha = (*self.color[:3], alpha)
                size = int(4 * (self.life / self.max_life))
                if size > 0:
                    pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), size)

    class HitEffect:
        def __init__(self, x, y, hit_type="perfect"):
            self.x = x
            self.y = y
            self.timer = 30
            self.hit_type = hit_type
            self.scale = 1.0
            
        def update(self):
            self.timer -= 1
            self.scale += 0.1
            self.y -= 2
            
        def draw(self, surface):
            if self.timer > 0:
                alpha = int(255 * (self.timer / 30))
                if self.hit_type == "perfect":
                    color = (255, 255, 100)
                    text = "PERFECT!"
                elif self.hit_type == "good":
                    color = (100, 255, 100)
                    text = "GOOD"
                else:
                    color = (255, 100, 100)
                    text = "MISS"
                    
                font_obj = pygame.font.Font(font_path, int(36 * self.scale))
                text_surface = font_obj.render(text, True, color)
                surface.blit(text_surface, (self.x - text_surface.get_width()//2, self.y))

    class Key:
        def __init__(self, x, y, colour1, colour2, key):
            self.x = x
            self.y = y
            self.colour1 = colour1
            self.colour2 = colour2
            self.key = key
            self.rect = pygame.Rect(x, y, 100, 40)
            self.glow_intensity = 0
            self.hit_animation = 0
            
        def update(self):
            if self.glow_intensity > 0:
                self.glow_intensity -= 5
            if self.hit_animation > 0:
                self.hit_animation -= 1
                
        def draw(self, surface, pressed=False):
            # Draw glow effect
            if self.glow_intensity > 0:
                glow_rect = pygame.Rect(self.x - 5, self.y - 5, 110, 50)
                glow_color = (255, 255, 255, self.glow_intensity)
                pygame.draw.rect(surface, (255, 255, 255), glow_rect, 3)
            
            # Draw main key
            color = self.colour2 if pressed else self.colour1
            if self.hit_animation > 0:
                # Add white flash when hit
                flash_intensity = self.hit_animation / 10
                color = tuple(min(255, c + int(100 * flash_intensity)) for c in color)
                
            pygame.draw.rect(surface, color, self.rect)
            pygame.draw.rect(surface, (255, 255, 255), self.rect, 2)

    keys = [
        Key(100, 520, (255, 100, 100), (255, 50, 50), pygame.K_a),
        Key(266, 520, (100, 255, 100), (50, 255, 50), pygame.K_s),
        Key(433, 520, (100, 100, 255), (50, 50, 255), pygame.K_d),
        Key(600, 520, (255, 255, 100), (255, 255, 50), pygame.K_f)
    ]

    def create_particles(x, y, color, count=10):
        for _ in range(count):
            velocity = (
                (pygame.time.get_ticks() % 10 - 5) * 2,
                (pygame.time.get_ticks() % 10 - 5) * 2
            )
            particles.append(Particle(x, y, color, velocity))

    def load(filename):
        rects = []
        mixer.init()
        mixer.music.load(filename + ".mp3")
        mixer.music.play()
        f = open(filename + ".txt", "r")
        data = f.readlines()
        
        for y in range(len(data)):
            for x in range(len(data[y])):
                if data[y][x] == "0":
                    rects.append(pygame.Rect(keys[x].rect.x, y*-100, 100, 60))
        return rects

    def draw_health_bar():
        # Background
        health_bg = pygame.Rect(20, 20, 200, 20)
        pygame.draw.rect(win, (100, 0, 0), health_bg)
        
        # Health fill
        health_width = int(200 * (health / max_health))
        health_fill = pygame.Rect(20, 20, health_width, 20)
        
        # Color changes based on health
        if health > 70:
            health_color = (0, 255, 0)
        elif health > 30:
            health_color = (255, 255, 0)
        else:
            health_color = (255, 0, 0)
            
        pygame.draw.rect(win, health_color, health_fill)
        pygame.draw.rect(win, (255, 255, 255), health_bg, 2)
        
        # Health text
        font_obj = pygame.font.Font(font_path, 24)
        health_text = font_obj.render(f"HP: {health}/{max_health}", True, (255, 255, 255))
        win.blit(health_text, (23, 50))

    def draw_combo_display():
        global combo_display_timer
        
        # Combo counter
        font_obj = pygame.font.Font(font_path, 48)
        combo_text = font_obj.render(f"COMBO: {combo_count}", True, (255, 255, 100))
        win.blit(combo_text, (SCREEN_WIDTH - 250, 20))
        
        # Max combo
        font_small = pygame.font.Font(font_path, 24)
        max_combo_text = font_small.render(f"MAX: {max_combo}", True, (200, 200, 200))
        win.blit(max_combo_text, (SCREEN_WIDTH - 250, 70))
        
        # Score
        score_text = font_obj.render(f"SCORE: {score}", True, (255, 255, 255))
        win.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, 20))
        
        # Combo multiplier effect
        if combo_count > 10:
            multiplier = min(combo_count // 10, 5)
            mult_text = font_small.render(f"x{multiplier} MULTIPLIER!", True, (255, 100, 255))
            win.blit(mult_text, (SCREEN_WIDTH - 250, 95))

    def draw_background():
        # Animated background
        time = pygame.time.get_ticks() / 1000
        for i in range(0, SCREEN_WIDTH, 50):
            color_shift = int(50 * math.sin(time + i * 0.01))
            color = (
                max(0, min(255, BACKGROUND[0] + color_shift)),
                max(0, min(255, BACKGROUND[1] + color_shift // 2)),
                max(0, min(255, BACKGROUND[2] + color_shift // 3))
            )
            pygame.draw.rect(win, color, (i, 0, 50, SCREEN_HEIGHT))

    try:
        map_rects = load("resources/WienerDog")
    except:
        print("Could not load song file, using empty map")
        map_rects = []

    def pause():
        paused = True
        pygame.mixer.music.pause()
        while paused:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE or event.key == pygame.K_SPACE:
                        paused = False
                        pygame.mixer.music.unpause()
            
            win.fill((0, 0, 0))
            font_obj = pygame.font.Font(font_path, 74)
            text = font_obj.render("PAUSED", True, (255, 255, 255))
            win.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, SCREEN_HEIGHT // 2 - text.get_height() // 2))
            
            resume_text = pygame.font.Font(font_path, 36).render("Press SPACE or ESC to resume", True, (200, 200, 200))
            win.blit(resume_text, (SCREEN_WIDTH // 2 - resume_text.get_width() // 2, SCREEN_HEIGHT // 2 + 50))
            
            pygame.display.update()
            clock.tick(FPS)

    # Main game loop
    while run:
        draw_background()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or event.key == pygame.K_SPACE:
                    pause()

        k = pygame.key.get_pressed()
        
        # Update keys
        for key in keys:
            key.update()
            key.draw(win, k[key.key])
        
        # Update and draw notes
        notes_to_remove = []
        for rect in map_rects[:]:  # Create a copy to iterate over
            pygame.draw.rect(win, (200, 100, 255), rect)
            pygame.draw.rect(win, (255, 255, 255), rect, 2)
            rect.y += 7
            
            hit = False
            for key in keys:
                if rect.colliderect(key.rect) and k[key.key]:
                    # Perfect hit
                    combo_count += 1
                    max_combo = max(max_combo, combo_count)
                    multiplier = min(combo_count // 10 + 1, 5)
                    score += 100 * multiplier
                    
                    key.glow_intensity = 100
                    key.hit_animation = 10
                    
                    create_particles(rect.centerx, rect.centery, key.colour1, 15)
                    hit_effects.append(HitEffect(rect.centerx, rect.centery, "perfect"))
                    
                    map_rects.remove(rect)
                    hit = True
                    break
            
            # Check if note missed (went too far down)
            if rect.y > SCREEN_HEIGHT:
                combo_count = 0
                health -= 10
                missed_notes += 1
                hit_effects.append(HitEffect(rect.centerx, HIT_ZONE_Y, "miss"))
                map_rects.remove(rect)
                
                if health <= 0:
                    quest_failed = True
                    # Game over logic could go here
        
        # Update and draw particles
        particles = [p for p in particles if p.life > 0]
        for particle in particles:
            particle.update()
            particle.draw(win)
        
        # Update and draw hit effects
        hit_effects = [effect for effect in hit_effects if effect.timer > 0]
        for effect in hit_effects:
            effect.update()
            effect.draw(win)
        
        # Draw UI elements
        draw_health_bar()
        draw_combo_display()
        
        # Draw hit zone indicator
        for key in keys:
            hit_zone = pygame.Rect(key.x, HIT_ZONE_Y - 30, 100, 60)
            pygame.draw.rect(win, (*key.colour1, 50), hit_zone)
            pygame.draw.rect(win, key.colour1, hit_zone, 2)

        if k[pygame.K_r] and quest_failed:
            map_rects = load("resources/WienerDog")
            run = True
            quest_result = None
            combo_count = 0
            max_combo = 0
            health = 100
            max_health = 100
            score = 0
            missed_notes = 0
            quest_failed = False
            
                    
        if quest_failed:
            # Quest failed screen
            draw_background()
            pygame.mixer.music.pause()
            fail_text = font_large.render("QUEST FAILED!", True, (255, 50, 50))
            fail_rect = fail_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))
            win.blit(fail_text, fail_rect)
            
            reason_text = font_medium.render("Too many notes missed!", True, (255, 100, 100))
            reason_rect = reason_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
            win.blit(reason_text, reason_rect)
            
            score_text = font_medium.render(f"Final Score: {score:,}", True, (255, 255, 255))
            score_rect = score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 30))
            win.blit(score_text, score_rect)
            
            retry_text = font_small.render("Press R to restart", True, (200, 200, 200))
            retry_rect = retry_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 80))
            win.blit(retry_text, retry_rect)
            
            quest_result = 'lose'
        
        elif len(map_rects) == 0 and music_started:
            # Display final score
            draw_background()
            final_text = font_large.render("SONG COMPLETE!", True, (255, 255, 100))
            final_rect = final_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))
            win.blit(final_text, final_rect)
            
            score_text = font_medium.render(f"Final Score: {score:,}", True, (255, 255, 255))
            score_rect = score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
            win.blit(score_text, score_rect)
            
            
            max_combo_text = font_medium.render(f"Max Combo: {max_combo}", True, (255, 255, 255))
            max_combo_rect = max_combo_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 65))
            win.blit(max_combo_text, max_combo_rect)
            
            quit_text = font_medium.render(f"Press E to return", True, (255, 255, 255))
            quit_rect = max_combo_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 100))
            win.blit(quit_text, quit_rect)
            
            quest_result = 'win'
            
            if k[pygame.K_e]:
                run = False
            
        
        pygame.display.update()
        clock.tick(FPS)
    return quest_result
